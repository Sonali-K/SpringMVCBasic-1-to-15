package com.cdac.employee.dao;

public class EmployeeDaoImpl {

}
