package com.cdac.employee.service;

public interface IEmployeeService {

}
